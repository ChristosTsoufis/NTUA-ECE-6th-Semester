/*
 * mandel.c
 *
 * A program to draw the Mandelbrot Set on a 256-color xterm.
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include "mandel-lib.h"
#include <errno.h>
#include <time.h>
#include <sched.h>

#define MANDEL_MAX_ITERATION 100000
#define _GNU_SOURCE
/***************************
 * Compile-time parameters *
 ***************************/

/*
 * Output at the terminal is is x_chars wide by y_chars long
*/
int y_chars = 50;
int x_chars = 90;

//we declare a pointer to semaphore
//sem_t keysem;
sem_t * sem_array;
int bound=0; //global , is protected via semaphore

 // we declare a struct in order to pass multiple arguments to the function from the thread
     struct arguments{
              int fd;
              int line;
              int N_SIZE;// the number of threads that are given from the user
              int thread_num;
    };

//END

/* The part of the complex plane to be drawn:
 * upper left corner is (xmin, ymax), lower right corner is (xmax, ymin)
*/

double xmin = -1.8, xmax = 1.0;
double ymin = -1.0, ymax = 1.0;

/*
 * Every character in the final output is
 * xstep x ystep units wide on the complex plane.
 */
double xstep;
double ystep;

/*
 * This function computes a line of output
 * as an array of x_char color values.
 */
void compute_mandel_line(int line, int color_val[])
{
        /*
         * x and y traverse the complex plane.
         */
        double x, y;

        int n;
        int val;

        /* Find out the y value corresponding to this line */
        y = ymax - ystep * line;

        /* and iterate for all points on this line */
        for (x = xmin, n = 0; n < x_chars; x+= xstep, n++) {

                /* Compute the point's color value */
                val = mandel_iterations_at_point(x, y, MANDEL_MAX_ITERATION);
                if (val > 255)
                        val = 255;

                /* And store it in the color_val[] array */
                val = xterm_color(val);
                color_val[n] = val;
        }
}

void output_mandel_line(int fd, int color_val[]){
/*
 * This function outputs an array of x_char color values
 * to a 256-color xterm.
 */
        int i;

        char point ='@';
        char newline='\n';

        for (i = 0; i < x_chars; i++) {
                /* Set the current color, then output the point */
                set_xterm_color(fd, color_val[i]);
                if (write(fd, &point, 1) != 1) {
                        perror("compute_and_output_mandel_line: write point");
                        exit(1);
                }
        }

        /* Now that the line is done, output a newline character */
        if (write(fd, &newline, 1) != 1) {
                perror("compute_and_output_mandel_line: write newline");
                exit(1);
        }
}

void *  compute_and_output_mandel_line(void * datatopass)
{

    struct arguments * dedomena = (struct arguments*) datatopass;

        int j    = dedomena->line;
        int fd   = dedomena->fd;
        int line = dedomena->line;
        int N    = dedomena->N_SIZE;
        int thread_code = dedomena->thread_num;
        int color_val[x_chars];

     while(j<y_chars){


        compute_mandel_line(line, color_val);            //to kanoun ola ta threads , den exei lock
                                                           // printf("thread = %d  \n",thread_code);

        // set the semahore
        sem_wait(&sem_array[j]);
        output_mandel_line(fd,color_val);
        line += N;

        bound++;

        if ( bound  >= y_chars ){
                break;
        }

        sem_post(&sem_array[j+1]);
        j=j+N;
    }

    //pthread_exit(NULL);
    return NULL;

}

int main(int argc , char * argv[] ){


char *  THREADS_NUM =(argv[1]); // the number of threads!
int N = atoi(THREADS_NUM);

/*we declare dynamicaly an array of semaphores , all of them are initialized to zero
 every thread coresponds to a semaphore , the n thread wakes up the n+1 semaphore
*/

int i=0;
 sem_array =(sem_t*) malloc(sizeof(sem_t)*50);
for(i=0 ; i < 50 ; i++ ) {
        sem_init(&sem_array[i],0,0);// ?
}
// set the first semaphore to 1 to open the "door" for the first thread

sem_post(&sem_array[0]);
//END

// we declare an array of threads dynamicaly:
        pthread_t  *id_array;
        id_array = (pthread_t*)malloc(sizeof(pthread_t)*N);
// END

//we declare an array of structs dynamicaly:
        struct arguments * data = (struct arguments *) malloc(sizeof(struct arguments)*N);
// END

        //int lia;
        xstep = (xmax - xmin) / x_chars;
        ystep = (ymax - ymin) / y_chars;
        for( i=0 ; i < N ; i++){
                (data+i)->N_SIZE = N;
                (data+i)->fd = 1;
                (data+i)->line=i;
                (data+i)->thread_num=i;

                int val1 = (data+i)->N_SIZE;
                int val2 = (data+i)->fd;
                int val3 = (data+i)->line;

                //printf( " INITIALIZATIONi :  N = %d , fd = %d , line = %d \n",val1,val2,val3);
                pthread_create(id_array+i,NULL,compute_and_output_mandel_line,&data[i]);
        }

//       for( i=0 ; i < N ; i++){
//           printf("THREAD CREATION \n");
//           pthread_create(id_array+i,NULL,compute_and_output_mandel_line,data+i);
//       }


        /*
         * draw the Mandelbrot Set, one line at a time.
         * Output is sent to file descriptor '1', i.e., standard output.
         */
//      for (line = 0; line < y_chars; line++) {
//              compute_and_output_mandel_line(1, line);
//      }
        //pthread_yield();// dinei mia protetraiotha se aytous poy perimenoun
        for( i = 0 ; i < N ; i++){
        pthread_join(*(id_array+i), NULL);
        }
        reset_xterm_color(1);
        return 0;
}
