#include<stdio.h>
#include<stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

//int write_file(int fd , const char * infile) ?

//void write_file(int fd , const char * infile);


void write_file(ssize_t fd2 , const char * infile  ) {

      ssize_t fd1;
      char    buff[1024] ;
      size_t  index_write , rcnt , wcnt ;
      size_t  len ;

     // open the file
     fd1 = open(infile,O_RDONLY);
     if ( fd1 == -1 ) {
                perror("open");
                printf("no such file or directory");
                exit(1);
     }



     do{

        index_write = 0 ;

        // read the file
        rcnt = read(fd1,buff,sizeof(buff)-1);
        if(rcnt == -1) {
           perror("read");
           return exit(1);
        }

       // write to the output file ( oti diavases apo to idio arxeio )
       if ( rcnt > 0 )  {
              //len = sizeof(buff);
              do{
                 wcnt=write(fd2,buff+index_write,rcnt-index_write);
                if(wcnt == -1){
                   perror("write");
                    exit(1);
                }
                index_write += wcnt;
              } while(index_write<rcnt);

        }


   // epanelave to diavasma apo to idio arxeio mexri na vreis EOF
     }while(rcnt > 0) ;

}


int main(int argc , char * argv[])
{
  ssize_t fd2;

// check arguments(argc??)

  if (argc < 3 ) { printf("put only 2 or 3 arguments" ) ; exit(1) ; }

  if (argc > 4 ) { printf("put only 2 or 3 arguments" ) ; exit(1) ; }

// open the target file:

  // if you have 2 arguments open the default target file

  // if you have 3 arguments open the target file

   if (argc==3) {
     fd2 = open("DEFAULT_target_file", O_WRONLY | O_CREAT , 0644);
     if ( fd2 == -1 ) {
                perror("open");
                //printf("no such file or directory");
                exit(1);
    }
  }

  if (argc==4){
   fd2 = open(argv[3], O_WRONLY | O_CREAT , 0644);
    if ( fd2 == -1 ) {
        perror("open");
        //printf("no such file or directory");
        exit(1);
   }
  }

 // Iterate on input files  [ ( read ) --> give to buffer ] and call write_file helper function :
 // pio apla open --> ( read , write ) (mexti na teleiwsei to kathe  arxeio )

  int i = 1;
  for ( i = 1 ; i < 3 ; i++) {
    write_file(fd2,argv[i])  ;
  }

 return -1 ;

}

// end main


