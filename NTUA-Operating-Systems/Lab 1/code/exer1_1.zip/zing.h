#ifndef ZING_H__
#define ZING_H__

void zing(void);

#endif