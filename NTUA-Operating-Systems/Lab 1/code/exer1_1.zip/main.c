#include <stdio.h>
#include <unistd.h>

void zing(){
    char *team;
    team = getlogin();
    printf("Hello and welcome team %s!\n",team);
}