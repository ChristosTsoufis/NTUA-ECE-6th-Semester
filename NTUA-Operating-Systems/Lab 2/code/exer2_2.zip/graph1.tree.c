# file that defines the tree
# lines starting with '#' are comments
# . each block defines a node
# . each node is defined as:
#    1st line:         name of node
#    2nd line:         number of children
#    subsequent lines: name(s) of children
# . blocks are seperated with empty lines
# . no comments are allowed within a block
# . nodes must be placed in a DFS order

A
3
B
C
D

B
1
E

E
0

C
1
F

F
0

D
0
