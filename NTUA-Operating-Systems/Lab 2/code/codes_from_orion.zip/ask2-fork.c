#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "proc-common.h"

#define SLEEP_PROC_SEC  10
#define SLEEP_TREE_SEC  3

// * Create this process tree:
// * A-+-B---D
// *   `-C
// */
 

struct tree_node {
   int exit_status;
   const char* name ;
   int  children_num ;
   struct tree_node * children[2];   
};

void creat_process_tree(struct tree_node * node, int number_children);

struct  tree_node * root;

void fork_procs(void)
{
	/*
	 * initial process is A.
	 */
// 	tree_node* root = &a;
//	change_pname("A");
//	printf("%d",getpid());
	creat_process_tree(root,root->children_num);
	printf("A: Sleeping...\n");
	sleep(SLEEP_PROC_SEC);

	/* ... */

//	printf("A: Exiting...\n");
//	exit(16);
}

/*
 * The initial process forks the root of the process tree,
 * waits for the process tree to be completely created,
 * then takes a photo of it using show_pstree().
 *
 * How to wait for the process tree to be ready?
 * In ask2-{fork, tree}:
 *      wait for a few seconds, hope for the best.
 * In ask2-signals:
 *      use wait_for_ready_children() to wait until
 *      the first process raises SIGSTOP.
 */
int main(void)
{


struct tree_node a;
struct tree_node b;
struct tree_node c;
struct tree_node d;
root = &a ; 
          a.exit_status =16;
          b.exit_status = 19 ;
          c.exit_status = 17 ;
          d.exit_status = 13 ;
	  a.name = "a";
	  b.name = "b" ;
	  c.name = "c" ;
	  d.name = "d" ;
	  a.children_num = 2;
	  b.children_num = 1 ;
	  c.children_num=0; ;
          d.children_num=0;
          a.children[0]=&b;
          a.children[1]=&c;
          b.children[0]=&d;
          root = &a;
			     
	pid_t pid;
	int status;

	/* Fork root of process tree */
	pid = fork();
	if (pid < 0) {
		perror("main: fork");
		exit(1);
	}
	if (pid == 0) {
		/* Child */
		fork_procs();
		exit(1);
	}

	/*
	 * Father
	 */
	/* for ask2-signals */
	/* wait_for_ready_children(1); */
	printf("code=");
	int code = getpid();
	printf("%d",code);
	/* for ask2-{fork, tree} */
	sleep(0.1);
        printf("now the tree");
	printf("\n");
	
	/* Print the process tree root at pid */
       	show_pstree(pid);
        printf("\n");
	/* for ask2-signals */
	/* kill(pid, SIGCONT); */

	/* Wait for the root of the process tree to terminate */
	pid = wait(&status);
	explain_wait_status(pid, status);

	return 0;
}



 void creat_process_tree ( struct tree_node * node , int number_children ) {
	change_pname(node->name);

	 printf(" %s %d  ","the  process   start := ",getpid());
	 printf("%s %s  ", ", the name of the node is  ",node->name);
         printf("\n");
         int status;
	 
	 if ( node->children_num == 0 ) {
		 // Leaf case
		 printf("The process with number %d is waiting\n", getpid()); 
		 sleep(2);
	         printf("%s %d %s %d  ","process is : " , getpid()  , " exiting and the exit status is : =",node->exit_status);
		 printf("\n");
		 exit ( node->exit_status ) ; return ;
	 } else { 
		int i = 0 ;
	        for (i = 0 ; i < node->children_num ; i++) {
	        	int  p = fork();
	           	if (p==0) {
		     		creat_process_tree(node->children[i],node->children_num);
			}				                                                                                                                      }
	}    
	
	printf(" %s %d %s ", "the process with number: ",getpid(),"is waiting....");	
	printf("\n");		                                                                                                                                                                                                           
	int j = 0;
 	for (j=0; j<node->children_num; j++) {
		waitpid(-1, &status, 0) ; 
	} 
	
	printf("%s %d %s %d  \n","process is : " , getpid()  , " and is  exiting , its  exit status is : =",node->exit_status);
        exit(node->exit_status);
}
