#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "proc-common.h"
#include "tree.h"

#define SLEEP_PROC_SEC  10
#define SLEEP_TREE_SEC  3

// * Create this process tree:
// * A-+-B---D
// *   `-C
// */
//


void creat_process_tree(struct tree_node  * root , int number_children) ;
struct tree_node * root; 


/*
 * The initial process forks the root of the process tree,
 * waits for the process tree to be completely created,
 * then takes a photo of it using show_pstree().
 *
 * How to wait for the process tree to be ready?
 * In ask2-{fork, tree}:
 *      wait for a few seconds, hope for the best.
 * In ask2-signals:
 *      use wait_for_ready_children() to wait until
 *      the first process raises SIGSTOP.
 */
int main(int  argc, char * argv[])
{

	 root = get_tree_from_file (argv[1]);
			     
	pid_t pid;
	int status;

	/* Fork root of process tree */
	pid = fork();
	if (pid < 0) {
		perror("main: fork");
		exit(1);
	}
	if (pid == 0) {
		/* Child */
		creat_process_tree(root,root->nr_children);
		exit(1);
	}

	/*
	 * Father
	 */
	/* for ask2-signals */
	/* wait_for_ready_children(1); */
	printf("code=");
	int code = getpid();
	printf("%d",code);
	/* for ask2-{fork, tree} */
	sleep(0.1);
        printf("now the tree");
	printf("\n");
	
	/* Print the process tree root at pid */
       	show_pstree(pid);
        printf("\n");
	/* for ask2-signals */
	/* kill(pid, SIGCONT); */

	/* Wait for the root of the process tree to terminate */
	pid = wait(&status);
	explain_wait_status(pid, status);

	return 0;
}




 void creat_process_tree ( struct tree_node * node , int number_children ) { 
	 change_pname(node->name);
	 printf(" %s %d  ","the  process   start := ",getpid());
	  printf("%s %c  ", ", the name of the node is  ",*(node->name));
          printf("\n");
	  if ( node->nr_children == 0 ) {
		  printf(" %s %d %s ", "the process with number: ",getpid(),"is waiting.");  printf("\n"); 
		  sleep(2);
	          printf("%s %d %s   ","process is : " , getpid()  , " is exiting.. : =");
		  printf("\n");
		  exit (16) ; return ;
	  } // base case 
          else{ int i = 0 ;
	       for(  i = 0 ; i < number_children ; i++ ) {
	           int  p = fork();
	           if(p==0) {
		     creat_process_tree(node->children+i,(node->children+i)->nr_children);
	             }				                                                                                                                                                                        	                                                                                            
	       }
	  }    
	  printf(" %s %d %s ", "the process with number: ",getpid(),"is waiting....");	printf("\n");		                                                                                                                                                                                                           
          int status;
	  int j = 0;
 	  for(j=0;j<number_children;j++){
		 pid_t p = waitpid(-1, &status, 0);
		 if (WIFEXITED(status)) {
			 // The child has exited (or returned from main)
			 printf("The child PID %d exited with code %d\n", p, WEXITSTATUS(status));
		 }  
	  } 
	  printf("%s %d %s  \n","process is : " , getpid()  , " and is  exiting" );
	  exit(16);
}
