#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

#include "tree.h"
#include "proc-common.h"

#define SLEEP_PROC_SEC  10
#define SLEEP_TREE_SEC  3

// * Create this process tree:
// * A-+-B---D
// *   `-C
// */
 



void creat_process_tree(struct tree_node * node,int pipe_read, int pipe_write);
int calculate(int a , int b , char  operator);
struct  tree_node * root;
//int fd[2];

//extern fd[2] = {0,0} ; // an initialization 

void fork_procs(void)
{
	/*
	 * initial process is A.
	 */
// 	tree_node* root = &a;
//	change_pname("A");
//	printf("%d",getpid());
//	creat_process_tree(root,root->children_num);
	printf("A: Sleeping...\n");
	sleep(SLEEP_PROC_SEC);

	/* ... */

//	printf("A: Exiting...\n");
//	exit(16);
}

/*
 * The initial process forks the root of the process tree,
 * waits for the process tree to be completely created,
 * then takes a photo of it using show_pstree().
 *
 * How to wait for the process tree to be ready?
 * In ask2-{fork, tree}:
 *      wait for a few seconds, hope for the best.
 * In ask2-signals:
 *      use wait_for_ready_children() to wait until
 *      the first process raises SIGSTOP.
 */
int main(int argc , char * argv[])
{
        root = get_tree_from_file(argv[1]);
			     
	pid_t pid;
	int status;

	int fd[2];
	pipe(fd);

	/* Fork root of process tree */
	pid = fork();
	if (pid < 0) {
		perror("main: fork");
		exit(0);
	}

	if (pid == 0) {
		/* Child */
		creat_process_tree(root,fd[0],fd[1]);
		exit(0);
	}

	/*
	 * Father
	 */
	/* for ask2-signals */
	// wait_for_ready_children(1); */
//	printf("code=")
//	int code = getpid();
//	printf("%d",code);
	/* for ask2-{fork, tree} */
	sleep(0.1);
//        printf("now the tree");
	printf("\n");
	/* Print the process tree root at pid */
    //   	show_pstree(pid);
        printf("\n");
	/* for ask2-signals */
	/* kill(pid, SIGCONT); */
       //	wait_for_ready_children(2);
	char buff;
	/* Wait for the root of the process tree to terminate */

	close(fd[1]);
	
	printf("main: Reading...\n");
	int n1 = read(fd[0], &buff, 1);
	printf("main: The final result: <%c>, %d bytes read\n", buff, n1);
	
	pid = wait(&status);
	explain_wait_status(pid, status);

	return 0;
}

int calculate(int a , int b , char  operator){
        if(operator == '*'){return a*b ; }
        if(operator == '+'){return a+b ; }
        return 0;
}



 void creat_process_tree (struct tree_node * node,int pipe_read,int pipe_write ) {
	change_pname(node->name);
        close(pipe_read);
	printf("process-name is %s and pid = %d  ",node->name,getpid());
        

	int    buff; 
	int     arr[2];
         printf("\n");
         int status;
	 if ( node->nr_children == 0 ){
		 char charbuff;
	         charbuff = node->name[0];
		 int buf = charbuff - '0';
		 if ( buf==1){buf=10;}
	   	 write(pipe_write,&buf,sizeof(buf));
		 close(pipe_write);
		 exit(0);
	 } else {
	        int i = 0;	
		int fd[2];
		pipe(fd);
		
		for (i=0  ; i < node-> nr_children ; i++) {	 	 
	                int  p = fork();
	               	if (p==0){
		     		creat_process_tree(node->children+i,fd[0],fd[1]);
			}
		}
                
		close(fd[1]);
		
		// Read results from each child
		int j  = 0 ;
		for( j=0; j<node->nr_children ;j++){ 
			read(fd[0],&buff,sizeof(buff));
		//	printf(" is read from pipe :   %c  \n",buff);
	      		arr[j]= buff;
		//	printf( "data-buff  = %c \n",arr[j]);	
		}
		
		printf("Waiting for children...\n");

	        // Wait for all children to terminate
		int z = 0;
		for( z = 0 ; z < node->nr_children ; z++){
			wait(&status);
		}
		printf("All have arrived\n");
	
           } 
        //if ( node->name =='*' || node->name=='+'){
        printf(" get in\n");	
        int  a = arr[0] ; //atoi(arr[0]);
        int  b = arr[1] ; //atoi(arr[1]);
        printf("a=%d b=%d\n", a, b);	
        int result =calculate(a,b,node->name[0]);
        // char res = ((result / 10) % 10) + '0' ; // Fixme!!
        printf("the result is %d \n",result); 
        int n1 = write(pipe_write, &result, sizeof(result));

        // printf("Wrote %d bytes into pipe descriptor %d\n", n1, pipe_write);
	close(pipe_write);
        exit(0);
	//return;	
            
   }


// we have one pipe for the two children , we do not wait to creat one children to make another but we create all childrens 
//and every children writes to his father, when the childrens are ready the father reads from the pipe 
