#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "tree.h"
#include "proc-common.h"

void creat_process_tree(struct tree_node * root , int number_children); 

void fork_procs(struct tree_node *root)
{
	/*
	 * Start
	 */
	printf("PID = %ld, name %s, starting...\n",(long)getpid(), root->name);
	change_pname(root->name);

	/* ... */

	/*
	 * Suspend Self
	 */
	raise(SIGSTOP);
	printf("PID = %ld, name = %s is awake\n",(long)getpid(), root->name);

	/* ... */

	/*
	 * Exit
	 */
	exit(0);
}

/*
 * The initial process forks the root of the process tree,
 * waits for the process tree to be completely created,
 * then takes a photo of it using show_pstree().
 *
 * How to wait for the process tree to be ready?
 * In ask2-{fork, tree}:
 *      wait for a few seconds, hope for the best.
 * In ask2-signals:
 *      use wait_for_ready_children() to wait until
 *      the first process raises SIGSTOP.
 */

int main(int argc, char *argv[])
{
	pid_t pid;
	int status;
	struct tree_node *root;

	if (argc < 2){
		fprintf(stderr, "Usage: %s <tree_file>\n", argv[0]);
		exit(1);
	}

	/* Read tree into memory */
	root = get_tree_from_file(argv[1]);

	
	

	/* Fork root of process tree */
	pid = fork();
	if (pid < 0) {
		perror("main: fork");
		exit(1);
	}
	if (pid == 0) {
		/* Child */
	//	fork_procs(root);
                creat_process_tree(root,root->nr_children);
		exit(1);
	}

	/*
	 * Father
	 */
	/* for ask2-signals */
	wait_for_ready_children(1);

	/* for ask2-{fork, tree} */
	/* sleep(SLEEP_TREE_SEC); */

	/* Print the process tree root at pid */
	show_pstree(pid);
	
	/* for ask2-signals */
	printf("%s \n","now the root is awake");
	kill(pid, SIGCONT);

	/* Wait for the root of the process tree to terminate */
	wait(&status);
	explain_wait_status(pid, status);

	return 0;
}

void creat_process_tree ( struct tree_node * node , int number_children ) {
	change_pname(node->name);
	printf(" %s %s START  \n ","the  process := ",node->name);
	int * pid_process = ( int * ) malloc(number_children * sizeof(int));
        char* name_children=(char * ) malloc(number_children * sizeof(char));
        printf("\n");
	int i =0;
	int k =0;
	int j =0;
        int status;
	   if ( node->nr_children == 0 ) {
	       raise(SIGSTOP);
	       printf(" %s %s %s ", "the process  ",node->name, ": woke-up");  printf("\n");
	       sleep(2);
	       printf("\n");
	       exit (0) ; return ;
	    } 
	    else{
              for(  i = 0 ; i < number_children ; i++ ) {
		  int  p = fork();
		  pid_process[i]=p;
		  if(p==0) {
		  name_children[i] =(node->children+i)->name;
	          creat_process_tree(node->children+i,(node->children+i)->nr_children);
		  }                                                                                                                                                                                      
                }
	      }
	    wait_for_ready_children(number_children);
	    printf("i am the %s and i have stopped \n  ",node->name);
	    raise(SIGSTOP);
	    printf(" %s %s %s ", "the process  ",node->name, ": woke-up");  printf("\n");   
	    for ( j = 0 ; j < number_children ; j++){
		 kill(pid_process[j],SIGCONT);
		 wait(&status);
	    }
	    exit(0);
                                                                                }
